<aside id="sidebar">
    <ul>
        <?php dynamic_sidebar(1); ?>
    </ul>
</aside>