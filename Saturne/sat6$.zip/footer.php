<footer id="pied">
    <p>Thème Saturne MatR - 2019</p>
</footer>

</div>
<?php wp_footer(); ?>
</body>
</html>